==============================================================
 WWE 2K26 ENTRANCE INSTALLER FREE 1.7
 How to use it
==============================================================

STEP 1 - CHECK YOUR GAME FOLDER
-------------------------------
Open the program. Near the top, under "Game directory", it
shows where it thinks WWE 2K26 is. On Steam this is usually:
   C:\Program Files (x86)\Steam\steamapps\common\WWE 2K26
If yours is somewhere else, click "Browse" next to it and pick
your WWE 2K26 game folder.

The small light next to "Sources" turns green when the program
has both an entrance file and your game folder.

CHOOSE YOUR MOD TOOL: DISCOVERY OR TRIBUTE
------------------------------------------
At the top right of the window, next to "Options", is
"Mod tool". Pick the tool you bake your mods with. The program
remembers your choice (and your folders) for next time.

DISCOVERY (the default)
  The program writes to the "discovery" folder inside your
  game folder: the menu entries go in discovery_data and the
  entrance's files go in _entrances. You bake both with
  Discovery Editor.
  Using a folder of your own instead? Put it in "Mod data
  folder" under "Game directory" (click "Browse"):
    - Choose the folder that has the same layout as
      discovery_data (with Entrances, Hide, Cutscene and Sdb
      folders inside it). It can be empty: any files an
      install needs that are not there yet are copied from
      your game when you install.
    - The entrance's files go in an "_entrances" folder right
      next to the folder you chose. The program makes it if
      it is not there.
    - Click "Default" to go back to the game's discovery
      folder.

TRIBUTE
  When you pick TRIBUTE, the program asks for your TRIBUTE
  "BakeMe" folder (the BakeMe folder inside your TRIBUTE
  folder, for example TRIBUTE 26\BakeMe).
    - EVERYTHING goes into BakeMe: the menu entries and the
      entrance's own files. There is no separate _entrances
      folder, so baking BakeMe with TRIBUTE carries the whole
      entrance.
    - To pick a different BakeMe folder later, click "Browse"
      next to "TRIBUTE BakeMe folder" under "Game directory".
    - Installed an entrance with version 1.5 or older into an
      "_entrances" folder next to BakeMe? Install it again
      with this version, then you can delete that old
      _entrances folder and stop baking it.
    - Arena Motion Overrides (an entrance that only plays in
      certain arenas) are a Discovery Editor feature. With
      TRIBUTE, choose the entrance for your wrestler directly
      in the game.

The grey line under the folder shows exactly where everything
will go.
Encrypted string files (for example the Sdb\ENG.sdb in
TRIBUTE's BakeMe) work too, and stay encrypted.


STEP 2 - OPEN AN ENTRANCE FILE
------------------------------
1. Click "Load New Entrance" (top right).
2. Pick the .entrance file you downloaded.
3. After a moment, the entrance appears in the middle of the
   window.

The entrance line shows:
- The entrance's name.
- Under the name, in grey, "Slot <number>:" and what is in
  that slot right now:
  "empty", "this entrance", or the name of the entrance that
  is already there.
- "Authored ID": the slot number the creator chose.
- Its status:
  "Ready to install"  - the slot is empty.
  "Installed"         - this exact entrance is already there.
  "Replaces <name>"   - another entrance is in that slot.
                        Installing will replace it.


ENTRANCES WITH THEIR OWN PROPS
------------------------------
Some entrances bring their own props, for example a flag that
unrolls behind the wrestler. Their files come inside the
.entrance and are installed with it, in
  _entrances\Props\<number>_<name>
  (TRIBUTE: BakeMe\Props\<number>_<name>)
The program also adds each prop to the game's prop list
  discovery_data\Props\PropsData\PropsData_AssetMap.jsfb
  (TRIBUTE: BakeMe\Props\PropsData\PropsData_AssetMap.jsfb)
(copying that file from your game first if it isn't there),
because the game only shows props that are on that list. You
bake them with the rest (see the BAKE step).
Entrances like this need version 1.5 or newer of this program:
1.3 and 1.4 install the prop's files but don't put it on the
list, so the prop never appears in the game. Versions before
1.3 say "Unsupported .entrance format version 7".
If the game or another mod already has a prop with the same
number, the program stops before changing anything (see IF
SOMETHING GOES WRONG).

ENTRANCES WITH THEIR OWN PYRO
-----------------------------
Entrances made in Entrance Studio can bring their own pyro list
(which of the game's own effects fire), installed as
  _entrances\Particle\Superstar\<number>.jsfb
  (TRIBUTE: BakeMe\Particle\Superstar\<number>.jsfb)
When it only names effects that are already in the game, nothing
else is needed. Entrances like this need version 1.4 or newer of
this program; older versions stop with "Particle dependency is
not a byte-identical WWE 2K26 base-game table".

Some entrances also bring pyro effects made in Entrance Studio
(for example a spark curtain or gerb smoke). Each one comes with
its own files, installed as
  _entrances\Particle\Popcorn\Game\Particles\EntranceStudio\
  (TRIBUTE: BakeMe\Particle\Popcorn\Game\Particles\EntranceStudio\)
and they are removed again when you uninstall the entrance.
Entrances like this need version 1.7 or newer of this program;
older versions refuse the file.


STEP 3 - INSTALL
----------------
1. Click "Install Entrance" at the bottom right.
2. If the slot already has an entrance in it, a box asks if you
   want to overwrite it, and names the entrance that is there.
   - Click "Overwrite Entrance" to replace it.
   - Click "Cancel" if you don't want that. Nothing is changed.
3. A small window shows what the program is doing. Wait for it
   to close.
4. When the message at the bottom turns GREEN, it worked.
   If it turns RED, read the message - nothing was changed.

If the entrance is already installed, the button says
"Already Installed" and there is nothing more to do.

The game must be CLOSED while you install.

If discovery_data (or your mod data folder, or BakeMe) is
missing any of the files an install needs (EntranceListData,
HideCtrlData, CutsceneNoRegistry, ENG.sdb, CsaDatabase or
CdefDatabase), the program copies them from your game automatically when you click
"Install Entrance". It never overwrites files you already have.
(You can also do this any time from "Options" at the top right,
then "Setup Mod Directory".)


STEP 4 - BAKE (VERY IMPORTANT)
------------------------------
After installing, you MUST bake before you start
the game:

DISCOVERY - bake BOTH of these folders with Discovery Editor:
  - discovery_data (or your mod data folder)
  - _entrances
  The program puts the entrance's files in "_entrances"
  (inside your discovery folder, or next to your mod data
  folder) and its menu entries in "discovery_data" (or your
  mod data folder).

TRIBUTE - bake BakeMe with TRIBUTE. Everything is in it.

If you forget to bake, the new entrance will
not show up in the game.


BACKUPS (YOUR SAFETY NET)
-------------------------
Before the program changes any file, it saves a copy in a
folder called "Backup", next to the program. Click
"Open Backup Folder" at the bottom left to see them. Each
install gets its own dated folder.

To save space you can untick the box
"Back up files before installing"
at the bottom. It stays unticked until you tick it again. A
failed install is still undone either way.

The Free version cannot uninstall entrances. To remove one, use
the Patreon Version: it puts the slot back the way the normal
game has it, using your game's own files, so it does not need
these backups.


IF SOMETHING GOES WRONG
-----------------------
The slot line says a file "is not in the mod data folder yet"
(or "...BakeMe folder yet")
  That's fine. Click "Install Entrance" and the program copies
  it from your game first.

"Loose-file install is disabled while WWE 2K26 is running"
  Close the game, then try again.

"...needs a new ID... The Free edition installs only at the
authored ID"
  The slot the creator chose can't be used. The Patreon Version
  can install the entrance in a different slot.

"...legacy format... cannot be installed"
  The entrance file is too old. Ask the creator for a new copy
  made with the current Entrance Studio.

"...already has a different file at ... and it is not one of
this slot's entrance's files" or
"The mod folder ...\... already has a file at ..."
  The entrance brings its own model or material file, and a
  different file with the same name is already there from
  another mod. Nothing was changed. Ask the creator to export
  the entrance again.

"The prop id ... is already used by ..."
  The entrance brings its own prop, and another mod already
  has a prop with that number. Nothing was changed. Ask the
  creator for a version of the entrance with a different prop
  number.

"The prop id ... is already the game's or another mod's prop"
  The entrance brings its own prop, and the game's prop list
  already has a different prop with that number. Nothing was
  changed. Ask the creator for a version of the entrance with
  a different prop number.

The entrance doesn't show up in the game
  Did you bake? Discovery: discovery_data AND _entrances.
  TRIBUTE: BakeMe. (STEP 4)

"The mod data folder was not found"
  The folder in "Mod data folder" is gone or mistyped. Browse
  to it again, or click "Default".

"The BakeMe folder was not found" or "This does not look like
TRIBUTE's BakeMe folder"
  Click "Browse" next to "TRIBUTE BakeMe folder" and choose
  the BakeMe folder inside your TRIBUTE folder (it has an
  Entrances folder in it). If you don't use TRIBUTE, set
  "Mod tool" back to Discovery.

The program won't start
  Make sure you extracted the whole folder and the "Tools"
  folder is right next to the program.

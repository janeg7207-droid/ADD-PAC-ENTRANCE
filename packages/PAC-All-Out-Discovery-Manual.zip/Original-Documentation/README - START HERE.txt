PAC ALL OUT ENTRANCE - WWE 2K26
Gorilla Modding Tools by Mr Creeper HD

Choose ONE method. Close the game and TRIBUTE first.

YOUR OTHER MODS
The entrance is added as a NEW entrance slot. If its number is already used, the installer picks a free one.
Your other mods are kept, and a backup is made automatically.
If asked about a conflict, choose Keep both.

TRIBUTE (easy)
1. Open "1 - EASY INSTALL FOR TRIBUTE" and run the installer.
   Windows may say "Windows protected your PC": click More info, then Run anyway.
2. Select your TRIBUTE folder if asked, then click INSTALL.
3. Open TRIBUTE, Bake, then play.

MANUAL (any tool)
Follow the README inside "2 - MANUAL FILES".

IN GAME - PICK THE ENTRANCE THAT MATCHES YOUR ARENA
  WrestleMania 41 (both nights) . "PAC All Out WrestleMania 41 SmackDown"
  SmackDown ..................... "PAC All Out WrestleMania 41 SmackDown"
  SummerSlam 2025 ............... "PAC All Out SummerSlam 2025"

ARENA - READ THIS
His chair in the crowd, the walk through the crowd and the barricade he stands on are placed for each arena.
In an arena that is not in the list above, the crowd and barricade part will not line up.
These are the game's own arenas: nothing else is needed.

KNOWN ISSUE
SummerSlam 2025: near his chair he walks through a lighting pillar. A fix is coming as an update.

WANT IT IN ANOTHER ARENA?
If you have a well-built arena - the latest AEW arena, or any other - contact me and send me the arena.
I will fit the entrance to it and put it out as a hotfix.

WRESTLER
Made and tested with PAC '26 by JOEMASHUPS (not included). The cameras are set for his height.
The whole entrance is built from the game's own animations.

REMOVE
Run the installer again, click Uninstall, then Bake.

CONTACT
x.com/MrCreeperHDYT
discord.gg/e9r6WPMsSF

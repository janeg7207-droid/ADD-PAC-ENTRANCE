Use a free ID and merge into your CURRENT data. If the ID or a file is taken, use the installer.
Never replace another mod's files or copy stock databases over your current data.

MANUAL INSTALL (TRIBUTE 26 or any other tool)

Each entrance has its own folder with only its files. Install the ones you want.

HOW TO INSTALL AN ENTRANCE
1. Close TRIBUTE 26.
2. Open the entrance's folder, for example "PAC All Out WrestleMania 41 SmackDown".
3. Copy everything INSIDE that folder into your BakeMe folder. Choose Merge folders.
   Do not replace files that belong to another mod.
4. Register it as a NEW entrance slot in your tool (TRIBUTE 26: Entrances -> Save As New) with the details below.
5. Bake, then play.

ENTRANCES

PAC All Out WrestleMania 41 SmackDown
  Folder: PAC All Out WrestleMania 41 SmackDown
  Cutscene ID 981  ·  Type Entrance  ·  Single  ·  phases 1000981 to 1400981
  Last frames: 479, 665, 1316, 520, 1232

PAC All Out SummerSlam 2025
  Folder: PAC All Out SummerSlam 2025
  Cutscene ID 979  ·  Type Entrance  ·  Single  ·  phases 1000979 to 1400979
  Last frames: 479, 665, 1326, 520, 1232

IF A CUTSCENE ID IS ALREADY USED BY ANOTHER MOD
  Use the installer in "1 - EASY INSTALL FOR TRIBUTE" instead. It moves the entrance to a free slot for you.

----------------------------------------
Gorilla Modding Tool by Mr Creeper HD

MY SOCIAL DETAILS
discord.gg/e9r6WPMsSF
x.com/MrCreeperHDYT
patreon.com/cw/GorillaModding
Gorilla Modding Tools
